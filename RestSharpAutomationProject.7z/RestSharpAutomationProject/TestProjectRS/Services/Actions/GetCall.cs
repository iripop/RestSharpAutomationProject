﻿using RestSharp;
using System.Collections.Generic;

namespace TestProjectRS.Services
{
    public class GetCall: ApiBase
    {
        //public static IRestResponse TriggerGetCall(string endpoint, DataFormat dataFormat, [Optional]IList<RequestParameter> parameters)
        //{
        //    RestRequest = RequestMethodManager.SetRequestMethod(RestRequest, parameters);
        //    if(parameters!=null) IRestRequest = RestClient.BaseUrl
        //}
    }
}
